import './App.css';
import Todos from './pages/todolist';

function App() {
  return <Todos/>;
}

export default App;
